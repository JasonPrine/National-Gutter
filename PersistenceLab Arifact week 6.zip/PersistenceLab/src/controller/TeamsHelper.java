package controller;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import persistence.teams;

public class TeamsHelper {
	static EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("PersistenceLab");
	
	
	

}
