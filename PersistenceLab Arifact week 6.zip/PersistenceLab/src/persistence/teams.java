package persistence;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Column;

@Entity
@Table
public class teams {
	@Id
	@GeneratedValue (strategy=GenerationType.IDENTITY)
	
	@Column(name = "ID")
	private int id;
	
	@Column(name = "TEAMNAME")
	private String teamname;
	
	@Column(name = "OWNER")
	private String owner;
	
	@Column(name = "WINS")
	private int wins;
	
	@Column(name = "LOSSES")
	private int losses;
	
	public teams() {
		
	}
	public teams(String teamname, String owner, int wins, int losses){
		this.teamname = teamname;
		this.owner = owner;
		this.wins = wins;
		this.losses = losses;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTeamname() {
		return teamname;
	}

	public void setTeamname(String teamname) {
		this.teamname = teamname;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public int getWins() {
		return wins;
	}

	public void setWins(int wins) {
		this.wins = wins;
	}

	public int getLosses() {
		return losses;
	}

	public void setLosses(int losses) {
		this.losses = losses;
	}
	@Override
	public String toString(){
		return this.teamname + "---" + this.owner;
	}

}
