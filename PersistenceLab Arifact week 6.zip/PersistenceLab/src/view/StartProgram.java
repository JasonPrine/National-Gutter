package view;
import java.util.List;
import java.util.Scanner;

import controller.TeamsHelper;
import persistence.teams;

public class StartProgram {
	static Scanner in = new Scanner(System.in);
	static TeamsHelper tea = new TeamsHelper();
	
	
	public static void main(String[] args){
		boolean goAgain = true;
		System.out.println("Welcome to the Carl's Crew Fantasy Football League.");
		
		while (goAgain){
			System.out.print("Would you like to update a record by owner or team? ");
			String choice = in.next();
			choice = choice.toLowerCase();
			
			if (choice == "owner"){
				System.out.print("Enter the owners name: ");
				String ownerName = in.nextLine();
				found = tea.searchOwner(ownerName);
				
			}
		
	}
	

}
}
